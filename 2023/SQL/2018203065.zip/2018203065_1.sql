select name from instructor where dept_name = 'Finance'
